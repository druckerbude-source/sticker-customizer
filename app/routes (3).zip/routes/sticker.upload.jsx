// app/routes/sticker.upload.jsx
// Wrapper route so the storefront can POST to /sticker/upload
// It reuses the existing implementation at /apps/sticker-configurator/sticker/upload

export { loader, action } from "./apps.sticker-configurator.sticker.upload.jsx";
