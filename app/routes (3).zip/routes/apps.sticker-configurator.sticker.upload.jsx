// app/routes/apps.sticker-configurator.sticker.upload.jsx
import { json } from "@remix-run/node";
import fs from "fs/promises";
import path from "path";
import crypto from "crypto";
import { Readable } from "stream";
import { pipeline } from "stream/promises";
import { authenticate } from "../shopify.server";

// ✅ NEW: central catalog source (server-side)
import { STICKER_CATALOG, STICKER_CATALOG_VERSION } from "../catalog/stickerCatalog.server";

// ✅ Safe defaults (Legacy calcPrice kann sonst später knallen, falls doch genutzt)
export const MIN_M2 = 0.1;
export const PRICE_PER_M2 = 250;

// ✅ Legacy (nicht mehr benutzt, kann später gelöscht werden)
export function calcPrice(widthCm, heightCm, quantity = 1) {
  const w = Number(widthCm) || 0;
  const h = Number(heightCm) || 0;

  const area = (w / 100) * (h / 100);
  const billedArea = Math.max(area, MIN_M2);
  const billedQuantity = Math.ceil(billedArea / MIN_M2);
  const effectiveQty = quantity || billedQuantity;
  const price = billedArea * PRICE_PER_M2;

  return { area: billedArea, quantity: effectiveQty, price };
}

function safeFilename(name) {
  const base = String(name || "upload").replace(/[^a-zA-Z0-9._-]/g, "_");
  const stamp = Date.now();
  const rnd = crypto.randomBytes(3).toString("hex");
  return `${stamp}-${rnd}-${base}`;
}

function isImageMime(m) {
  const mime = String(m || "").toLowerCase();
  return mime.startsWith("image/");
}

/**
 * ✅ NEW: Flatten server catalog to client catalog:
 * out[shapeKey] = [{ shapeKey, sizeKey, label, widthCm, heightCm, variantId, meta, productHandle, sizeOptionKey }]
 */
function toClientCatalog(src) {
  const out = {};
  for (const [shapeKey, def] of Object.entries(src || {})) {
    out[shapeKey] = (def?.sizes || []).map((s) => ({
      shapeKey,
      sizeKey: s.sizeKey,
      label: s.label,
      widthCm: s.widthCm,
      heightCm: s.heightCm,
      variantId: s.variantId, // <- WICHTIG
      meta: def?.meta || null,
      productHandle: def?.productHandle || null,
      sizeOptionKey: def?.sizeOptionKey || null,
    }));
  }
  return out;
}

export async function loader() {
  // ✅ Wichtig: Wir geben den Katalog NICHT flach als def.sizes[] aus,
  // sondern als vollständige Struktur inkl. colors.<colorKey>.sizes[].variantId
  // (siehe stickerCatalog.server.js).
  // Das Frontend normalisiert diese Struktur und kann damit die korrekte Variante
  // für Weiß/Transparent/Farbig auswählen.
  return json({
    ok: true,
    route: "/apps/sticker-configurator/sticker/upload",
    catalogVersion: STICKER_CATALOG_VERSION,
    catalog: STICKER_CATALOG,
  });
}

export async function action({ request }) {
  if (request.method !== "POST") {
    return json({ ok: false, error: "Method not allowed" }, { status: 405 });
  }

  // ✅ Embedded Admin ODER Storefront App Proxy
  let admin = null;
  let isAppProxyRequest = false;

  try {
    const u = new URL(request.url);
    const hasShop = u.searchParams.has("shop");
    const hasHmac = u.searchParams.has("hmac") || u.searchParams.has("signature");
    isAppProxyRequest = hasShop && hasHmac;

    if (isAppProxyRequest) {
      await authenticate.public.appProxy(request);
    } else {
      ({ admin } = await authenticate.admin(request));
    }
  } catch (e) {
    console.error("[UPLOAD AUTH ERROR]", e);
    return json(
      {
        ok: false,
        error: isAppProxyRequest
          ? "Unauthorized (app proxy validation failed)"
          : "Unauthorized (admin session token validation failed)",
      },
      { status: 401 }
    );
  }

  try {
    const formData = await request.formData();
    const file = formData.get("file");

    if (!file || typeof file.stream !== "function") {
      return json({ ok: false, error: "invalid file" }, { status: 400 });
    }

    const mime = String(file.type || "").toLowerCase();
    if (!isImageMime(mime)) {
      return json({ ok: false, error: "Nur Bilddateien sind erlaubt." }, { status: 400 });
    }

    const maxBytes = 15_000_000;
    const size = Number(file.size || 0);
    if (size > maxBytes) {
      return json(
        { ok: false, error: `Bild zu groß (max ${Math.round(maxBytes / 1e6)}MB).` },
        { status: 400 }
      );
    }

    // ✅ Optional: Meta fürs UI/Logging (ohne Preis!)
    const shape = String(formData.get("shape") || "").toLowerCase();
    const sizeKey = String(formData.get("sizeKey") || "");
    const widthCm = Number(formData.get("widthCm") || 0) || 0;
    const heightCm = Number(formData.get("heightCm") || 0) || 0;
    const freeformBorderMm = Number(formData.get("freeformBorderMm") || 0) || 0;
    const bgColor = String(formData.get("bgColor") || "");

    const variantRaw = String(formData.get("variant") || "preview").toLowerCase();
    const variant = variantRaw === "original" ? "original" : "preview";

    const uploadDir = path.join(process.cwd(), "public", "uploads", "sticker-configurator", variant);
    await fs.mkdir(uploadDir, { recursive: true });

    const fileName = safeFilename(file.name);
    const diskPath = path.join(uploadDir, fileName);

    const nodeStream = Readable.fromWeb(file.stream());
    const writeStream = (await import("fs")).createWriteStream(diskPath);

    await pipeline(nodeStream, writeStream);

    const u = new URL(request.url);
    const proxyBase = "/apps/sticker-configurator";

    const url = isAppProxyRequest
      ? `${proxyBase}/uploads/sticker-configurator/${variant}/${fileName}`
      : `${u.origin}/uploads/sticker-configurator/${variant}/${fileName}`;

    // ✅ BACKWARD COMPATIBLE Response
    return json({
      ok: true,

      // ✅ backward compatible (Preview im Frontend)
      uploadedUrl: url,
      serverPreviewUrl: url,

      // ✅ bleibt
      url,
      fileName,
      meta: {
        shape,
        sizeKey,
        widthCm,
        heightCm,
        freeformBorderMm,
        bgColor,
      },
    });
  } catch (err) {
    console.error("[UPLOAD ACTION ERROR]", err);
    return json({ ok: false, error: err?.message || "unknown error" }, { status: 500 });
  }
}
