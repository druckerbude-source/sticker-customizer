export { loader, action } from "./proxy.$.jsx";
