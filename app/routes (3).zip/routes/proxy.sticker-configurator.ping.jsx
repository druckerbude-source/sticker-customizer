export { loader, action } from "./proxy.ping.jsx";
