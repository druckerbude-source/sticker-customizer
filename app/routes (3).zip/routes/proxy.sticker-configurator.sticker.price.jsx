export { loader, action } from "./apps.sticker-configurator.sticker.price.jsx";
