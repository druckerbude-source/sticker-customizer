export { loader, action } from "./apps.sticker-configurator.sticker.preview.jsx";
