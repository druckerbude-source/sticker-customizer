export { loader, action } from "./apps.sticker-configurator.sticker.upload.jsx";
