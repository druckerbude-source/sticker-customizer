import { json } from "@remix-run/node";
import fs from "fs/promises";
import path from "path";
import { authenticate } from "../shopify.server";
import { uploadBufferAsShopifyFile } from "../lib/shopifyFiles.server";

// ==============================
// Performance-Schalter
// ==============================
// WICHTIG:
// Shopify-File-Upload ist i.d.R. der größte Zeitfresser (Netzwerk + Shopify Verarbeitung).
// Deshalb default: lokal speichern, Shopify Upload nur wenn der Client explizit true sendet.
const DEFAULT_UPLOAD_PNG_TO_SHOPIFY = false;
const DEFAULT_UPLOAD_SVG_TO_SHOPIFY = false;

// Schutz: sehr große Base64 Uploads abweisen (optional)
const MAX_DATAURL_MB = 35;

const EXPORT_DIR = path.join(process.cwd(), "public", "exports", "sticker-configurator");

// Debug-Logging nur wenn benötigt
const DEBUG = process.env.NODE_ENV !== "production" && process.env.DEBUG_EXPORT === "1";

// ==============================
// Auth (Admin Session Token ODER App-Proxy HMAC)
// ==============================
function isAppProxyRequest(request) {
  const u = new URL(request.url);
  return u.searchParams.has("shop") && (u.searchParams.has("signature") || u.searchParams.has("hmac"));
}

async function getAdminClientOrThrow(request) {
  const auth = String(request.headers.get("authorization") || "");

  // 1) Admin-Bearer Token -> admin auth (typisch für Embedded Admin)
  if (/^bearer\s+/i.test(auth)) {
    const { admin } = await authenticate.admin(request);
    return admin;
  }

  // 2) App-Proxy -> appProxy auth (typisch für Storefront)
  if (isAppProxyRequest(request)) {
    const { admin } = await authenticate.public.appProxy(request);
    return admin;
  }

  // 3) Dev/Local fallback: admin, sonst 401 (kein doppeltes Try, spart Zeit)
  const { admin } = await authenticate.admin(request);
  return admin;
}

function normalizeShape(rawShape) {
  const s = String(rawShape || "").toLowerCase();
  if (s === "circle" || s === "round" || s === "rund") return "round";
  if (s === "oval" || s === "oval_portrait") return "oval";
  if (s === "square") return "square";
  if (s === "rect" || s === "rectangle" || s === "rect_landscape") return "rect";
  if (s === "square_rounded" || s === "rect_rounded" || s === "rect_landscape_rounded" || s === "rounded") {
    return "rounded";
  }
  if (s === "freeform") return "freeform";
  return "rect";
}

function clampInt(n, min, max) {
  const x = Math.round(Number(n));
  if (!Number.isFinite(x)) return min;
  return Math.min(max, Math.max(min, x));
}

function approxBase64BytesLen(base64Str) {
  // 4 chars ~ 3 bytes
  return Math.floor((base64Str.length * 3) / 4);
}

let _exportDirReady = false;
async function ensureDirOnce(dir) {
  if (_exportDirReady) return;
  try {
    await fs.mkdir(dir, { recursive: true });
  } catch {}
  _exportDirReady = true;
}

// ==============================
// PNG Größe aus IHDR lesen (ohne externe Libs)
// ==============================
function readPngSize(pngBuffer) {
  try {
    if (!pngBuffer || pngBuffer.length < 24) return null;
    if (pngBuffer[0] !== 0x89 || pngBuffer[1] !== 0x50 || pngBuffer[2] !== 0x4e || pngBuffer[3] !== 0x47) {
      return null;
    }
    const w = pngBuffer.readUInt32BE(16);
    const h = pngBuffer.readUInt32BE(20);
    if (!w || !h) return null;
    return { w, h };
  } catch {
    return null;
  }
}

// ------------------------------
// Background / transparency helpers
// ------------------------------
function normalizeBgInput(bgMode, bgColor, exportTransparent) {
  const forcedTransparent = !!exportTransparent;
  const mode = String(forcedTransparent ? "transparent" : (bgMode || "color")).toLowerCase();
  const raw = String(bgColor ?? "").trim();
  const low = raw.toLowerCase();
  const isTrans = !raw || low === "transparent" || low === "none";
  const hasFill = mode !== "transparent" && !isTrans;
  return { mode, raw, hasFill };
}

export async function action({ request }) {
  if (request.method !== "POST") {
    return json({ ok: false, error: "Method not allowed" }, { status: 405 });
  }

  // Auth
  let admin;
  try {
    admin = await getAdminClientOrThrow(request);
  } catch (e) {
    console.error("[EXPORT AUTH ERROR]", e);
    return json({ ok: false, error: "Unauthorized" }, { status: 401 });
  }

  try {
    const body = await request.json().catch(() => ({}));

    const {
      renderedDataUrl,
      imageUrl,
      shape: rawShape = "rect",

      // hilfreich für Logging/Fallback, aber NICHT als Zwangsgröße
      widthPx,
      heightPx,


      // ✅ optional: bessere Freiform-Exports (Mask/Border/Rect)
      rectWidthPx,
      rectHeightPx,
      freeformCutMaskDataUrl,
      freeformBorderPx,
      bgMode = "color",
      bgColor = "#ffffff",
      exportTransparent = false,
      fitMode,

      // Perf Flags (Client kann hier steuern)
      uploadPngToShopify = DEFAULT_UPLOAD_PNG_TO_SHOPIFY,
      uploadSvgToShopify = DEFAULT_UPLOAD_SVG_TO_SHOPIFY,
    } = body || {};

    const shapeKey = normalizeShape(rawShape);

    if (DEBUG) {
      console.log("[EXPORT] req", {
        shape: rawShape,
        shapeKey,
        widthPx,
        heightPx,
        bgMode,
        bgColor,
        exportTransparent: !!exportTransparent,
        hasRenderedDataUrl: !!renderedDataUrl,
        uploadPngToShopify: !!uploadPngToShopify,
        uploadSvgToShopify: !!uploadSvgToShopify,
      });
    }

    const bg = normalizeBgInput(bgMode, bgColor, exportTransparent);
    const fill = bg.raw || "#ffffff";
    const hasBgFill = !!bg.hasFill;

    const { origin } = new URL(request.url);
    const rawBase = process.env.SHOPIFY_APP_URL || origin;
    const appBase = rawBase.replace(/\/$/, "");

    const getPreserve = (s) => {
      if (s === "freeform") return "xMidYMid meet";
      if (fitMode === "contain") return "xMidYMid meet";
      if (fitMode === "cover") return "xMidYMid slice";
      return "xMidYMid slice";
    };

    // =========================================================
    // MODE 1: Canvas-Export (renderedDataUrl) -> PNG + SVG Wrapper
    // =========================================================
    if (renderedDataUrl && typeof renderedDataUrl === "string") {
      const match = renderedDataUrl.match(/^data:image\/png;base64,(.+)$/);
      if (!match) {
        return json({ ok: false, error: "renderedDataUrl muss data:image/png;base64,... sein." }, { status: 400 });
      }

      const base64 = match[1] || "";
      const approxBytes = approxBase64BytesLen(base64);
      if (approxBytes > MAX_DATAURL_MB * 1024 * 1024) {
        return json({ ok: false, error: `renderedDataUrl zu groß (>${MAX_DATAURL_MB}MB).` }, { status: 413 });
      }

      const pngBuffer = Buffer.from(base64, "base64");

      // echte PNG Pixelmaße verwenden (verhindert Verzerrung)
      const size = readPngSize(pngBuffer);
      const fallbackW = clampInt(widthPx ?? 1, 1, 20000);
      const fallbackH = clampInt(heightPx ?? 1, 1, 20000);
      const exportW = clampInt(size?.w ?? fallbackW, 1, 20000);
      const exportH = clampInt(size?.h ?? fallbackH, 1, 20000);

      await ensureDirOnce(EXPORT_DIR);

      const ts = Date.now();
      const pngName = `${ts}-sticker.png`;
      const svgName = `${ts}-sticker.svg`;

      const localPngUrl = `${appBase}/exports/sticker-configurator/${pngName}`;
      const localSvgUrl = `${appBase}/exports/sticker-configurator/${svgName}`;

      // 1) PNG Upload (optional Shopify, default AUS für Speed)
      let pngUrl = localPngUrl;
      let pngFileId = null;

      if (uploadPngToShopify) {
        try {
          const up = await uploadBufferAsShopifyFile(admin, {
            buffer: pngBuffer,
            filename: pngName,
            mimeType: "image/png",
            resource: "IMAGE",
            contentType: "IMAGE",
            alt: "Sticker export PNG",
          });
          pngUrl = up.url;
          pngFileId = up.fileId;
        } catch (e) {
          console.error("[EXPORT PNG SHOPIFY WARN]", e);
        }
      }

      // Wenn nicht zu Shopify (oder Upload scheitert): lokal speichern (schnell)
      if (!pngFileId) {
        await fs.writeFile(path.join(EXPORT_DIR, pngName), pngBuffer);
        pngUrl = localPngUrl;
      }

      
    // 2) Cutline / Clip (Freiform via Maske, Standardformen via Geometrie)
    let cutPath = "";
    const strokeW = Math.max(2, Math.round(Math.min(exportW, exportH) * 0.01));

    const freeformMask = typeof freeformCutMaskDataUrl === "string" ? freeformCutMaskDataUrl.trim() : "";
    const freeformMaskOk = shapeKey === "freeform" && /^data:image\/png;base64,/.test(freeformMask);

    // Standardformen: Geometrie-Cutline wie gehabt
    if (shapeKey !== "freeform") {
      if (shapeKey === "round") {
        const r = Math.min(exportW, exportH) / 2;
        const cx = exportW / 2;
        const cy = exportH / 2;
        cutPath = `<circle cx="${cx}" cy="${cy}" r="${r}" fill="none" stroke="#ff00ff" stroke-width="${strokeW}" />`;
      } else if (shapeKey === "oval") {
        const cx = exportW / 2;
        const cy = exportH / 2;
        cutPath = `<ellipse cx="${cx}" cy="${cy}" rx="${exportW / 2}" ry="${exportH / 2}" fill="none" stroke="#ff00ff" stroke-width="${strokeW}" />`;
      } else if (shapeKey === "rounded") {
        const radius = Math.round(Math.min(exportW, exportH) * 0.2);
        cutPath = `<rect x="0" y="0" width="${exportW}" height="${exportH}" rx="${radius}" ry="${radius}" fill="none" stroke="#ff00ff" stroke-width="${strokeW}" />`;
      } else {
        cutPath = `<rect x="0" y="0" width="${exportW}" height="${exportH}" fill="none" stroke="#ff00ff" stroke-width="${strokeW}" />`;
      }
    }

    // 3) Hintergrund + Image Rendering
    // - Standardformen: bgRect optional + imageTag (wie bisher)
    // - Freiform: wenn freeformCutMaskDataUrl vorhanden -> SVG-Maske nutzen, um exakt die Konfigurator-Form zu clippen
    const preserve = getPreserve(shapeKey);

    let defsExtra = "";
    let bgRect = "";
    let imageTag = "";

    if (freeformMaskOk) {
      const maskId = "ffmask_" + ts.toString(36);
      const cutFilterId = "ffcut_" + ts.toString(36);

      // Cutline bei Freiform als "Edge" aus der Maske (rasterisiert im SVG, aber sauber um die Form)
      const cutRadius = Math.max(1, Math.round(strokeW / 2));

      defsExtra = `
<defs>
  <mask id="${maskId}" maskUnits="userSpaceOnUse" maskContentUnits="userSpaceOnUse" style="mask-type:alpha">
    <image href="${freeformMask}" x="0" y="0" width="${exportW}" height="${exportH}" preserveAspectRatio="none" />
  </mask>

  <filter id="${cutFilterId}" x="-20%" y="-20%" width="140%" height="140%" color-interpolation-filters="sRGB">
    <feMorphology in="SourceAlpha" operator="dilate" radius="${cutRadius}" result="d" />
    <feComposite in="d" in2="SourceAlpha" operator="out" result="edge" />
    <feFlood flood-color="#ff00ff" flood-opacity="1" result="c" />
    <feComposite in="c" in2="edge" operator="in" result="colEdge" />
    <!-- Wichtig: NICHT über SourceGraphic legen, sonst wird die Maske als weiße Fläche sichtbar -->
  </filter>
</defs>`;

      // Hintergrund nur wenn nicht transparent
      bgRect = hasBgFill ? `<rect x="0" y="0" width="${exportW}" height="${exportH}" fill="${fill}" mask="url(#${maskId})" />` : "";

      // PNG wird auf die Freiform-Maske geclippt (kein schwarzer Hintergrund, da kein bgRect wenn transparent)
      // preserveAspectRatio: bei Freiform "none", weil rendered PNG i.d.R. schon die korrekte Pixelgröße hat
      imageTag = `<image href="${renderedDataUrl}" x="0" y="0" width="${exportW}" height="${exportH}" preserveAspectRatio="none" />`;

      // Cutline als Filter-Edge der Maske
      cutPath = `<image href="${freeformMask}" x="0" y="0" width="${exportW}" height="${exportH}" preserveAspectRatio="none" filter="url(#${cutFilterId})" />`;
    } else {
      // Standard (oder Freiform ohne Maske): wie bisher
      bgRect = hasBgFill && shapeKey !== "freeform" ? `<rect x="0" y="0" width="${exportW}" height="${exportH}" fill="${fill}" />` : "";
      imageTag = `<image href="${pngUrl}" x="0" y="0" width="${exportW}" height="${exportH}" preserveAspectRatio="${preserve}" />`;
    }

    const svgContent = `<?xml version="1.0" encoding="UTF-8"?>
<svg width="${exportW}" height="${exportH}" viewBox="0 0 ${exportW} ${exportH}" xmlns="http://www.w3.org/2000/svg">
  ${defsExtra}
  ${bgRect}
  ${imageTag}
  ${cutPath}
</svg>`;

      // 4) SVG (standard lokal, optional Shopify)
      let svgUrl = localSvgUrl;
      let svgFileId = null;

      if (uploadSvgToShopify) {
        try {
          const up = await uploadBufferAsShopifyFile(admin, {
            buffer: Buffer.from(svgContent, "utf8"),
            filename: svgName,
            mimeType: "image/svg+xml",
            resource: "FILE",
            contentType: "FILE",
            alt: "Sticker export SVG",
          });
          svgUrl = up.url;
          svgFileId = up.fileId;
        } catch (e) {
          console.error("[EXPORT SVG SHOPIFY WARN]", e);
        }
      }

      if (!svgFileId) {
        await fs.writeFile(path.join(EXPORT_DIR, svgName), svgContent, "utf8");
        svgUrl = localSvgUrl;
      }

      return json({
        ok: true,
        svgUrl,
        pngUrl,
        svgFileId,
        pngFileId,
        exportWidthPx: exportW,
        exportHeightPx: exportH,
        perf: {
          uploadPngToShopify: !!uploadPngToShopify,
          uploadSvgToShopify: !!uploadSvgToShopify,
        },
      });
    }

    // =========================================================
    // MODE 2: Vektor-Fallback (wenn renderedDataUrl fehlt)
    // =========================================================
    if (!imageUrl) {
      return json({ ok: false, error: "imageUrl ist erforderlich, wenn kein renderedDataUrl gesendet wird." }, { status: 400 });
    }

    if (!widthPx || !heightPx) {
      return json({ ok: false, error: "widthPx und heightPx sind erforderlich." }, { status: 400 });
    }

    const w = clampInt(widthPx, 1, 20000);
    const h = clampInt(heightPx, 1, 20000);

    const clipId = "clip_" + Date.now().toString(36) + "_" + Math.random().toString(36).slice(2, 8);

    let clipShape = "";
    let cutPath = "";

    if (shapeKey === "round") {
      const cx = w / 2;
      const cy = h / 2;
      const r = Math.min(w, h) / 2;
      clipShape = `<circle cx="${cx}" cy="${cy}" r="${r}" />`;
      cutPath = `<circle cx="${cx}" cy="${cy}" r="${r}" fill="none" stroke="#ff00ff" stroke-width="${Math.min(w, h) * 0.01}" />`;
    } else if (shapeKey === "oval") {
      const cx = w / 2;
      const cy = h / 2;
      clipShape = `<ellipse cx="${cx}" cy="${cy}" rx="${w / 2}" ry="${h / 2}" />`;
      cutPath = `<ellipse cx="${cx}" cy="${cy}" rx="${w / 2}" ry="${h / 2}" fill="none" stroke="#ff00ff" stroke-width="${Math.min(w, h) * 0.01}" />`;
    } else if (shapeKey === "rounded") {
      const radius = Math.min(w, h) * 0.2;
      clipShape = `<rect x="0" y="0" width="${w}" height="${h}" rx="${radius}" ry="${radius}" />`;
      cutPath = `<rect x="0" y="0" width="${w}" height="${h}" rx="${radius}" ry="${radius}" fill="none" stroke="#ff00ff" stroke-width="${Math.min(w, h) * 0.01}" />`;
    } else if (shapeKey === "freeform") {
      clipShape = `<rect x="0" y="0" width="${w}" height="${h}" />`;
      cutPath = "";
    } else {
      clipShape = `<rect x="0" y="0" width="${w}" height="${h}" />`;
      cutPath = `<rect x="0" y="0" width="${w}" height="${h}" fill="none" stroke="#ff00ff" stroke-width="${Math.min(w, h) * 0.01}" />`;
    }

    const bgRect =
      hasBgFill && shapeKey !== "freeform" ? `<rect x="0" y="0" width="${w}" height="${h}" fill="${fill}" />` : "";

    const preserve = getPreserve(shapeKey);
    const imageTag = `<image href="${imageUrl}" x="0" y="0" width="${w}" height="${h}" preserveAspectRatio="${preserve}" />`;

    const useClip = shapeKey !== "freeform";
    const defsBlock = useClip ? `<defs><clipPath id="${clipId}">${clipShape}</clipPath></defs>` : "";
    const contentGroup = useClip ? `<g clip-path="url(#${clipId})">${imageTag}</g>` : `${imageTag}`;

    const svgContent = `<?xml version="1.0" encoding="UTF-8"?>
<svg width="${w}" height="${h}" viewBox="0 0 ${w} ${h}" xmlns="http://www.w3.org/2000/svg">
  ${defsBlock}
  ${bgRect}
  ${contentGroup}
  ${cutPath}
</svg>`;

    await ensureDirOnce(EXPORT_DIR);

    const fileName = `${Date.now()}-sticker.svg`;
    await fs.writeFile(path.join(EXPORT_DIR, fileName), svgContent, "utf8");

    const svgUrl = `${appBase}/exports/sticker-configurator/${fileName}`;
    return json({ ok: true, svgUrl, pngUrl: null, exportWidthPx: w, exportHeightPx: h });
  } catch (err) {
    console.error("[EXPORT ERROR]", err);
    return json({ ok: false, error: err?.message || String(err) }, { status: 500 });
  }
}

export function loader() {
  return json({ ok: false, error: "GET not supported" }, { status: 405 });
}
